function setup() {
  createCanvas(windowWidth, windowHeight);
}

function draw() {
  background("#9bf6ff");//背景藍色
  stroke("#bf4342")//框線顏色為紅色
  noFill();//不要充滿顏色
  rectMode(CENTER)


  for(var i=0;i<10;i=i+4)//i++ ==>i=i+1
  {
   ellipse(25+(i*10),25,50)//在座標(25,25)畫一個直徑50圓
   rect(25+(i*10),25(j*30),50)//方框座標
   ellipse(50+(i*10),50(j*30),25)
  }
  
}
